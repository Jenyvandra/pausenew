<?php
/**
 * Template Post Type: webinars
 *
 * @version 5.3.1
 */
get_header();
if (class_exists('acf')) {
    $webinar_dr_image = get_field('webinar_dr_image');
    $webinar_dr_name = get_field('webinar_dr_name');
    $webinar_dr_designation = get_field('webinar_dr_designation');
    $webinar_dr_desc = get_field('webinar_dr_desc');
    $webinar_first_content = get_field('webinar_first_content');
    $webinar_second_content = get_field('webinar_second_content');
    $webinar_third_content = get_field('webinar_third_content');
    $webinar_four_title = get_field('webinar_four_title');
    $webinar_four_content = get_field('webinar_four_content');
}
?>
<section class="small-banner">
    <div class="container">
        <div class="row">
            <div class="small-banner-inner">
                <?php the_breadcrumb(); ?>
            </div>
        </div>
    </div>
</section>
<div id="content" class="site-content pf-btmspace">
    <!-- Hook to add something nice -->
    <?php bs_after_primary(); ?>
    <div id="main" class="site-main <?= bootscore_container_class(); ?>" data-aos="fade-up">
        <div class="row">
            <div class="col-12 col-xl-8">
                <header class="entry-header">
                    <?php
                    $iframe_html = get_field('iframe_html');
                    if ($iframe_html != NULL) {
                        ?>
                        <div class="ratio ratio-16x9"><?= $iframe_html; ?></div>
                        <?php
                    } else {
                        bootscore_post_thumbnail();
                    }
                    ?>
                    <h1><?= get_the_title(); ?></h1>
                    <p class="entry-meta">
                        <small class="text-body-tertiary">
                            <?php bootscore_author(); ?> | <?php bootscore_date(); ?>
                        </small>
                    </p>
                </header>
                <div class="profile-detail-wrapper">
                    <?php if(!empty($webinar_dr_image)) {
                    ?>
                    <div class="profile-box box-left">
                        <img src="<?php echo $webinar_dr_image['url'];?>" alt="<?php echo $webinar_dr_image['alt'];?>">
                    </div>
                    <?php }
                    ?>
                    <div class="profile-box box-right">
                        <?php if(!empty($webinar_dr_name)) {
                        ?>
                        <h3><?php echo $webinar_dr_name; ?></h3>
                        <?php } if(!empty($webinar_dr_designation) || !empty($webinar_dr_desc))  {?>
                        <div class="dr-desg-detail">
                            <div class="profile-desg">
                                <h5><?php echo $webinar_dr_designation; ?></h5>
                            </div>
                            <div class="qualification">
                                <h6><?php echo $webinar_dr_desc; ?></h6>
                            </div>
                        </div>
                        <?php }
                        ?>
                    </div>
                </div>
                <div class="entry-content-data">
                    <?php if(!empty($webinar_first_content)) {
                    ?>
                    <div class="entry-one">
                        <?php echo $webinar_first_content; ?>
                    </div>
                    <?php } if(!empty($webinar_second_content)) {
                    ?>
                     <div class="entry-two">
                        <?php echo $webinar_second_content; ?>
                    </div>
                    <?php } if(!empty($webinar_third_content)) {
                    ?>
                    <div class="entry-three">
                        <?php echo $webinar_third_content; ?>
                    </div>
                    <?php } if(!empty($webinar_four_title) || !empty($webinar_four_content)) {
                    ?>
                    <div class="entry-four">
                        <h5><?php echo $webinar_four_title; ?></h5>
                        <?php echo $webinar_four_content; ?>
                    </div>
                    <?php } the_content(); ?>
                </div>
                <?php
                $display_registration_form = get_field('display_registration_form');
                if ($display_registration_form) {
                    ?>
                    <div class="container">
                        <div class="contact-inner reg-form aos-init" data-aos="fade-up">
                            <div class="row">
                                <div class="col-12">
                                    <h3>Webinars Registration Form</h3>
                                    <?= do_shortcode('[contact-form-7 id="ed123cf" title="Webinar Registration Form"]'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <footer class="entry-footer clear-both">
                    <div class="mb-4">
                        <?php bootscore_tags(); ?>
                    </div>
                    <!-- Related posts using bS Swiper plugin -->
                    <?php if (function_exists('bootscore_related_posts')) bootscore_related_posts(); ?>
                    <!-- <nav aria-label="bS page navigation">
                              <ul class="pagination justify-content-center">
                                <li class="page-item">
                    <?php previous_post_link('%link'); ?>
                                </li>
                                <li class="page-item">
                    <?php next_post_link('%link'); ?>
                                </li>
                              </ul>
                            </nav> -->
                    <?php comments_template(); ?>
                </footer>
            </div>
            <?php get_sidebar(); ?>
        </div>
    </div>
</div>
<?php
get_footer();
